<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePecisTable extends Migration {
   public function up()
   {
       $this->forge->addField([
           'id' => [
               'type' => 'INT',
               'constraint' => 11,
               'auto_increment' => true,
           ],
           'nama' => [
               'type' => 'VARCHAR', 
               'constraint' => 225,
           ],
           'kategori' => [
               'type' => 'VARCHAR',
               'constraint' => 225,
           ],
           'bahan' => [
               'type' => 'VARCHAR',
               'constraint' => 225,
           ],
           'ukuran' => [
               'type' => 'VARCHAR',
               'constraint' => 10,
           ],
           'warna' => [
               'type' => 'VARCHAR',
               'constraint' => 100,
           ],
           'stok' => [
               'type' => 'INT',
               'constraint' => 11,
           ],
           'harga' => [
               'type' => 'INT',
               'constraint' => 16,
           ],
           'gambar' => [
               'type' => 'VARCHAR',
               'constraint' => 255,
               'null' => true,
           ],
           'created_at' => [
               'type' => 'DATETIME',
               'null' => true,
           ],
           'updated_at' => [
               'type' => 'DATETIME',
               'null' => true,
           ]
       ]);

       $this->forge->addKey('id', true);
       $this->forge->createTable('pecis');
   }

   public function down()
   {
       $this->forge->dropTable('pecis');
   }
}