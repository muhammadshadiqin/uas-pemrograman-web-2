<?= $this->extend('admin/template') ?>

<?= $this->section('main') ?>
<h2 class="mb-5">Tambah Peci</h2>

<div class="w-50">
    <form action="<?= base_url('admin/daftar-peci/tambah') ?>" enctype="multipart/form-data" method="POST">
        <div class="mb-3">
            <label for="nama">Nama Peci</label>
            <input type="text" class="form-control" name="nama" id="nama" required>
        </div>
        <div class="mb-3">
            <label for="kategori">Kategori</label>
            <input type="text" class="form-control" name="kategori" id="kategori" required>
        </div>
        <div class="mb-3">
            <label for="bahan">Bahan</label>
            <input type="text" class="form-control" name="bahan" id="bahan" required>
        </div>
        <div class="mb-3">
            <label for="warna">Warna</label>
            <input type="text" class="form-control" name="warna" id="warna" required>
        </div>
        <div class="mb-3">
            <label for="ukuran">Ukuran</label>
            <input type="text" class="form-control" name="ukuran" id="ukuran" required>
        </div>
        <div class="mb-3">
            <label for="gambar">Gambar</label>
            <input type="file" name="gambar" id="gambar" class="form-control" accept="image/*" required>
        </div>
        <div class="mb-3">
            <label for="harga">Harga</label>
            <input type="number" class="form-control" name="harga" id="harga" required>
        </div>
        <div class="mb-3 d-flex justify-content-between">
            <a href="<?= base_url('admin/daftar-peci') ?>" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>

<?= $this->endSection() ?>
