<?= $this->extend('admin/template'); ?>
<?= $this->section('main'); ?>

<h2 class="mb-5 fw-bold text-primary">
    <i class="fas fa-hat-cowboy me-2"></i> Daftar Peci
</h2>

<div class="d-flex justify-content-between align-items-center mb-4">
    <a href="<?= base_url('admin/daftar-peci/tambah') ?>" class="btn btn-primary btn-lg">
        <i class="fas fa-plus me-1"></i> Tambah Peci
    </a>
</div>

<div class="card shadow-sm border-0 rounded-4">
    <div class="card-body">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th scope="col" class="text-center">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Bahan</th>
                    <th scope="col">Ukuran</th>
                    <th scope="col">Warna</th>
                    <th scope="col" class="text-center">Stok</th>
                    <th scope="col" class="text-center">Gambar</th>
                    <th scope="col" class="text-center">Harga</th>
                    <th scope="col" class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!empty($pecis)): ?>
                <?php foreach ($pecis as $key => $peci): ?>
                <tr>
                    <th scope="row" class="text-center"><?= $key + 1 ?></th>
                    <td><?= htmlspecialchars($peci['nama']) ?></td>
                    <td><?= htmlspecialchars($peci['kategori']) ?></td>
                    <td><?= htmlspecialchars($peci['bahan']) ?></td>
                    <td><?= htmlspecialchars($peci['ukuran']) ?></td>
                    <td><?= htmlspecialchars($peci['warna']) ?></td>
                    <td class="text-center"><?= htmlspecialchars($peci['stok']) ?></td>
                    <td class="text-center">
                        <img src="<?= base_url(htmlspecialchars($peci['gambar'])) ?>" alt="<?= htmlspecialchars($peci['nama']) ?>" class="img-thumbnail" style="width: 100px; height: 100px; object-fit: cover;">
                    </td>
                    <td class="text-center">Rp<?= number_format($peci['harga'], 0, ',', '.') ?></td>
                    <td class="text-center">
                        <a href="<?= base_url('admin/daftar-peci/edit/' . htmlspecialchars($peci['id'])) ?>" class="btn btn-success btn-sm">
                            <i class="fas fa-edit me-1"></i> Edit
                        </a>
                        <a href="<?= base_url('admin/daftar-peci/hapus/' . htmlspecialchars($peci['id'])) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus item ini?')">
                            <i class="fas fa-trash me-1"></i> Hapus
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="10" class="text-center">Data peci tidak tersedia</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection(); ?>
